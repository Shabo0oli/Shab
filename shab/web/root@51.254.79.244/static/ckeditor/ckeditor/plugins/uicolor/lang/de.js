﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","de",{title:"UI-Farbpipette",preview:"Live-Vorschau",config:"Fügen Sie diese Zeichenfolge in die Datei config.js ein.",predefined:"Vordefinierte Farbsätze"});